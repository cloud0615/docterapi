package com.example.doctorapi.controller;

import com.example.doctorapi.model.Doctor;
import com.example.doctorapi.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @PostMapping("/add")
    public ResponseEntity<Doctor> addDoctor(@RequestBody Doctor doctor) {
        Doctor addedDoctor = doctorService.addDoctor(doctor);
        return ResponseEntity.ok(addedDoctor);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Doctor>> getDoctors(
            @RequestParam(required = false) String specialization,
            @RequestParam(required = false) String location) {
        List<Doctor> doctors = doctorService.getDoctors(specialization, location);
        return ResponseEntity.ok(doctors);
    }
}
