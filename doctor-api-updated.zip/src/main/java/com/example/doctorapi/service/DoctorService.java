package com.example.doctorapi.service;

import com.example.doctorapi.model.Doctor;
import com.example.doctorapi.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public Doctor addDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public List<Doctor> getDoctors(String specialization, String location) {
        if (specialization != null && location != null) {
            return doctorRepository.findBySpecializationContainingIgnoreCase(specialization);
        } else if (specialization != null) {
            return doctorRepository.findBySpecializationContainingIgnoreCase(specialization);
        } else if (location != null) {
            return doctorRepository.findByLocationContainingIgnoreCase(location);
        }
        return doctorRepository.findAll();
    }
}
